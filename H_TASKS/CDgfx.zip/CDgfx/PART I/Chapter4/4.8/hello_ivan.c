#define x 
#define xx 
#define xxx 

#include <stdio.h>

int main()
{
x(139 xx 113 xxx 180);x(21 xx 21 xxx 79);x(9 xx 6 xxx 99);
x(35 xx 35 xxx 42);x(80 xx 19 xxx 12);x(44 xx 1 xxx 1);
x(8 xx 7 xxx 47);x(125 xx 85 xxx 155);x(23 xx 73 xxx 22);
x(76 xx 111 xxx 218);x(92 xx 7 xxx 13);x(77 xx 22 xxx 66);
}
