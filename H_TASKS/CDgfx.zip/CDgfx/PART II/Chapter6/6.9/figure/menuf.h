#define IDM_CLEAR         1
#define IDM_EXIT          2

#define IDM_RECTANGLE     10
#define IDM_ELLIPSE       11
#define IDM_PIE           12

#define IDM_ABOUT         20
